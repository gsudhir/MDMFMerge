# Databricks notebook source
# MAGIC %md
# MAGIC #### Data Merge
# MAGIC Reads the split file and merges it with existing delta table or creates the table for historical load.

# COMMAND ----------

# DBTITLE 1,Utilities
# MAGIC %run ../Tools/Utilities

# COMMAND ----------

# DBTITLE 1,Widgets
# Obtain the parameters sent by Azure Data Factory
#dbutils.widgets.removeAll()

# Input Parameters
dbutils.widgets.text("SourceInstanceURL", "", "")
dbutils.widgets.text("SourceContainerName", "", "")
dbutils.widgets.text("SourceFilePath", "", "")
dbutils.widgets.text("SourceFileExtension", "", "")
dbutils.widgets.text("ObjectSchema", "", "")
dbutils.widgets.text("ColumnSchema", "", "")
dbutils.widgets.text("InputParameters", "", "")
dbutils.widgets.text("SourceKeySecretName", "", "")
dbutils.widgets.text("NbRunParameters", "", "")

# Output Parameters
dbutils.widgets.text("OutputParameters", "", "")

# COMMAND ----------

# DBTITLE 1,Variables
##source variables
nb_run_parameters = json.loads(dbutils.widgets.get("NbRunParameters"))
source_instance_url = dbutils.widgets.get("SourceInstanceURL")
source_container_name = dbutils.widgets.get("SourceContainerName")
source_object_schema = json.loads(dbutils.widgets.get("ObjectSchema"))
source_column_schema = json.loads(dbutils.widgets.get("ColumnSchema"))
source_file_path = dbutils.widgets.get("SourceFilePath")
source_file_extension = dbutils.widgets.get("SourceFileExtension")
input_parameters = json.loads(dbutils.widgets.get("InputParameters"))
source_key_secret_name = dbutils.widgets.get("SourceKeySecretName")

if source_object_schema.get("skipIngestion","N") == "N":
  start_date = None
  end_date = None

##output variables
output_parameters = json.loads(dbutils.widgets.get('OutputParameters'))
output_container_name = output_parameters['outputContainerName']
output_file_path = output_parameters['outputFilePath']
output_file_extension = output_parameters['outputFileExtension']

##derived variables
kv_scope_name = nb_run_parameters['kvScopeName']
service_principal_id = nb_run_parameters['servicePrincipalId']
service_principal_secret_name = nb_run_parameters['servicePrincipalSecretName']
tenant_id = nb_run_parameters['tenantId']
source_name = output_parameters['sourceName']
load_date = output_parameters['loadDate']
storage_name = return_storage_name(source_instance_url)

##external table vars
create_external_table_flag = input_parameters['createExternalTable']
external_database_name = input_parameters['externalDatabaseName']
external_table_name = input_parameters['externalTableName']
delta_vacuum_days = input_parameters['deltaVacuumDays']
delta_output_columns = input_parameters['deltaOutputColumns']
delta_partition_columns = input_parameters['deltaPartitionColumns']

##additional optional attributes
num_partitions = input_parameters.get("numPartitions",None)
shuffle_partitions = input_parameters.get("shufflePartitions",None)
if shuffle_partitions:
  spark.conf.set("spark.sql.shuffle.partitions",int(shuffle_partitions))
else:
  spark.conf.set("spark.sql.shuffle.partitions","auto")

notebook_status = "Succeeded" #default status

# COMMAND ----------

# DBTITLE 1,Read the file from source
try:
  df = read_from_adls(kv_scope_name, service_principal_id, service_principal_secret_name, tenant_id, storage_name, source_container_name, source_file_path, source_file_extension)
  print(f"Total records in source file: {df.count()}")
  
except Exception as ex:
  notebook_status = "Failed"
  raise Exception('ERROR: {}'.format(ex))

# COMMAND ----------

# DBTITLE 1,Write Delta Output
try:
  if 'ryanre' in source_name.lower():
    df = df.dropDuplicates()
  
  if 'ryanre' in source_name.lower() and 'transaction' in external_table_name.lower():
    df = df.filter('right(date_of_booking, 4) >= 2023')
    df = df.filter('pairing_date_latest <> "" or liquid_balance <> ""')

  df = df.withColumn('sourceName', lit(source_name))
  
  if source_name.lower() not in ('fxloader', 'ryanre', 'brokasure', 'stetson', 'workday'):
    if '_CT/' not in source_file_path:
      write_mode = 'overwrite'
      df = df.select('*', lit(load_date).alias('mergeLoadDate'), lit(load_date).alias('mergeModifiedDate'))
    else:
      write_mode = 'merge'
      merge_load_timestamp = spark.sql(f'select mergeLoadDate from {external_database_name}.{external_table_name} limit 1').collect()[0][0]
      df = df.select('*', lit(merge_load_timestamp).alias('mergeLoadDate'), lit(load_date).alias('mergeModifiedDate'))
  else:
    write_mode = 'merge'
    df = df.select('*', lit(load_date).alias('mergeLoadDate'), lit(load_date).alias('mergeModifiedDate'))
  
  if output_container_name and create_external_table_flag.upper() == 'Y': 
    #writes into delta format
    write_split_to_delta(kv_scope_name, service_principal_id, service_principal_secret_name, tenant_id, storage_name, output_container_name, output_file_path, output_file_extension, df, external_database_name, external_table_name, object_schema = source_object_schema, num_partitions = num_partitions, delta_output_columns = delta_output_columns, delta_partition_columns = delta_partition_columns, write_mode = write_mode)
    
    #creates Databricks External Table (using abfss protocol, direct connection to ADLS delta lake entity)
    create_external_table(kv_scope_name, service_principal_id, service_principal_secret_name, tenant_id, storage_name, output_container_name, output_file_path, "delta", external_database_name, external_table_name, delta_vacuum_days)
  
except Exception as ex:
  notebook_status = "Failed"
  raise Exception(f"Error: {ex}")

# COMMAND ----------

# DBTITLE 1,Output
notebook_output = str({"notebookOutput": {"execution":"DMerge_01_DataMerge notebook executed"},"notebookStatus": notebook_status})
dbutils.notebook.exit(notebook_output)
