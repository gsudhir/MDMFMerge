
-- =============================================
-- Create Date: 2023-10-11
-- Description: DMergeLog object creation script.
-- =============================================


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'DMergeLog')
BEGIN
	CREATE TABLE [dbo].[DMergeLog] (
		[DMergeLogId] [bigint] IDENTITY(1,1) NOT NULL,
		[DSplitLogId] [bigint] NOT NULL,
		[FwkLogId] [bigint] NOT NULL,
		[FwkFactoryId] [bigint] NOT NULL,
		[FactoryName] [nvarchar](50) NOT NULL,
		[FactoryParameters] [nvarchar](max) NULL,
		[MainRunId] [nvarchar](50) NOT NULL,
		[ModuleRunId] [nvarchar](50) NOT NULL,
		[ModuleName] [nvarchar](50) NOT NULL,
		[PipelineRunId] [nvarchar](50) NULL,
		[PipelineName] [nvarchar](50) NULL,
		[PipelineStartTime] [datetime2] NULL,
		[PipelineEndTime] [datetime2] NULL,
		[PipelineDuration] [int] NULL,
		[PipelineStatus] [nvarchar](50) NULL,
		[PipelineError] [nvarchar](max) NULL,
		[ActivityRunId] [nvarchar](50) NULL,
		[ActivityName] [nvarchar](50) NULL,
		[ActivityType] [nvarchar](50) NULL,
		[ActivityStartTime] [datetime2] NULL,
		[ActivityEndTime] [datetime2] NULL,
		[ActivityDuration] [nvarchar](50) NULL,
		[ActivityStatus] [nvarchar](50) NULL,
		[ActivityError] [nvarchar](max) NULL,
		[ActivityIntegrationRuntime] [nvarchar](max) NULL,
		[ActivityOutputDetail] [nvarchar](max) NULL,
		[NbStatus] [nvarchar](50) NULL,
		[NbRunPageURL] [nvarchar](500) NULL,
		[NbRunError] [nvarchar](max) NULL,
		[NbRunOutput] [nvarchar](max) NULL,
		[FwkConfigId] [bigint] NOT NULL,
		[ObjectName] [nvarchar](255) NOT NULL,
		[SourceModuleName] [nvarchar](50) NOT NULL,
		[SourceInstanceURL] [nvarchar](100) NOT NULL,
		[SourceContainerName] [nvarchar](50) NOT NULL,
		[SourceFilePath] [nvarchar](500) NOT NULL,
		[SourceFileExtension] [nvarchar](50) NOT NULL,
		[SourceKeySecretName] [nvarchar](50) NULL,
		[SourceName] [nvarchar](max) NOT NULL,
		[FwkObjectMetadataId] [bigint] NULL,
		[ObjectSchema] [nvarchar](max) NULL,
		[ColumnSchema] [nvarchar](max) NULL,
		[FwkTriggerId] [bigint] NOT NULL,
		[TriggerName] [nvarchar](100) NOT NULL,
		[DMergeConfigId] [bigint] NULL,
		[FwkTargetId] [bigint] NOT NULL,
		[DSplitConfigId] [bigint] NOT NULL,
		[InputParameters] [nvarchar](max) NOT NULL,
		[OutputParameters] [nvarchar](max) NOT NULL,
		[DMergeEntityUID] [nvarchar](50) NOT NULL,
		[BatchGroupId] [bigint] NULL,
		[ActiveFlag] [nvarchar](5) NOT NULL,
		[LastModifiedDate] [datetime2] NOT NULL,
		[LastModifiedBy] [nvarchar](100) NOT NULL
	CONSTRAINT [PK_DMergeLog] PRIMARY KEY CLUSTERED (
		[DMergeLogId] ASC
	) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	CONSTRAINT [UK_DMergeLog_1] UNIQUE NONCLUSTERED (
		[FwkFactoryId] ASC,
		[ModuleRunId] ASC,
		[DMergeConfigId] ASC
	) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY];
END