
-- =============================================
-- Create Date: 2023-10-11
-- Description: DMergeConfig object creation script.
-- =============================================


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'DMergeConfig')
BEGIN
	CREATE TABLE [dbo].[DMergeConfig] (
		[DMergeConfigId] [bigint] IDENTITY(1,1) NOT NULL,
		[FwkFactoryId] [bigint] NOT NULL,
		[FwkTriggerId] [bigint] NOT NULL,
		[FwkTargetId] [bigint] NOT NULL,
		[DSplitConfigId] [bigint] NOT NULL,
		[FwkConfigId] [bigint] NOT NULL,
		[ObjectName] [nvarchar](255) NOT NULL,
		[InputParameters] [nvarchar](max) NOT NULL,
		[DMergeEntityUID] [nvarchar](50) NOT NULL,
		[BatchGroupId] [bigint] NULL,
		[ActiveFlag] [nvarchar](5) NOT NULL,
		[LastModifiedDate] [datetime2] NOT NULL,
		[LastModifiedBy] [nvarchar](100) NOT NULL,
	CONSTRAINT [PK_DMergeConfig] PRIMARY KEY CLUSTERED (
		[DMergeConfigID] ASC
	) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	CONSTRAINT [UK_DMergeConfig_1] UNIQUE NONCLUSTERED (
		[DSplitConfigId] ASC,
		[FwkConfigId] ASC,
		[ObjectName] ASC
	) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	CONSTRAINT [UK_DMergeConfig_2] UNIQUE NONCLUSTERED 
	(
		[DMergeEntityUID] ASC
	) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY];
END