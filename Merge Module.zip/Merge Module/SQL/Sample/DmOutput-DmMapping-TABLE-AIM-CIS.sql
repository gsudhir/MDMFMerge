
-- =============================================
-- Source Name: AIM-CIS
-- Date Created: 2024-03-19
-- Description: MDMF dbo.DMergeConfig Insert Script
-- =============================================


DECLARE 
    @factoryId BIGINT = (SELECT FwkFactoryId FROM dbo.FwkFactory WHERE FactoryName = '{#factoryName#}'),
    @triggerIdHist BIGINT = (SELECT FwkTriggerId FROM dbo.FwkTrigger WHERE TriggerName = 'TR_EDH_History'),
    @triggerIdCDC BIGINT = (SELECT FwkTriggerId FROM dbo.FwkTrigger WHERE TriggerName = 'TR_EDH_15Min'),
    @targetId BIGINT = (SELECT FwkTargetId FROM dbo.FwkTarget WHERE TargetName = 'adls-bronze-protected'),
    @sourceId BIGINT = (SELECT FwkSourceId FROM dbo.FwkSource WHERE SourceName = 'AIM-CIS'),
    @fwkConfigId BIGINT,
    @dSplitConfigId BIGINT,
    @dSplitEntityUID nvarchar(50),
	@dmOutputId BIGINT,
    @error nvarchar(255)

IF @factoryId IS NULL
    throw 500401, 'FactoryName {#factoryName#} not found in dbo.FwkFactory', 1

IF @triggerIdHist IS NULL
    throw 500401, 'TriggerName TR_EDH_History not found in dbo.FwkTrigger', 1

IF @triggerIdCDC IS NULL
    throw 500401, 'TriggerName TR_EDH_15Min not found in dbo.FwkTrigger', 1

IF @sourceId IS NULL
    throw 500401, 'SourceName AIM-CIS not found in dbo.FwkSource', 1

IF @targetId IS NULL
    throw 500401, 'TargetName adls-bronze-protected not found in dbo.FwkTarget', 1

/****** Object: compadmt  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/compadmt')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'compadmt',
	 'Merge/Protected/SRC=AIM-CIS/compadmt',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "compadmt","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'compadmt',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "compadmt","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/compadmt'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/compadmt')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'compadmt' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject compadmt not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_compadmt_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_compadmt_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: company  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/company')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'company',
	 'Merge/Protected/SRC=AIM-CIS/company',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "company","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'company',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "company","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/company'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/company')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'company' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject company not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_company_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_company_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: coverage  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/coverage')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'coverage',
	 'Merge/Protected/SRC=AIM-CIS/coverage',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "coverage","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'coverage',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "coverage","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/coverage'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/coverage')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'coverage' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject coverage not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_coverage_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_coverage_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: division  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/division')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'division',
	 'Merge/Protected/SRC=AIM-CIS/division',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "division","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'division',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "division","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/division'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/division')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'division' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject division not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_division_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_division_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: employees  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/employees')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'employees',
	 'Merge/Protected/SRC=AIM-CIS/employees',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "employees","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'employees',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "employees","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/employees'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/employees')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'employees' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject employees not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'rts_employees_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject rts_employees_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: endorse  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/endorse')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'endorse',
	 'Merge/Protected/SRC=AIM-CIS/endorse',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "endorse","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'endorse',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "endorse","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/endorse'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/endorse')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'endorse' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject endorse not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_endorse_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_endorse_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: insured  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/insured')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'insured',
	 'Merge/Protected/SRC=AIM-CIS/insured',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "insured","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'insured',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "insured","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/insured'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/insured')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'insured' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject insured not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_insured_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_insured_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: invoicedetail  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/invoicedetail')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'invoicedetail',
	 'Merge/Protected/SRC=AIM-CIS/invoicedetail',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "invoicedetail","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'invoicedetail',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "invoicedetail","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/invoicedetail'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/invoicedetail')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'invoicedetail' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject invoicedetail not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_invoicedetail_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_invoicedetail_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: invoiceheader  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/invoiceheader')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'invoiceheader',
	 'Merge/Protected/SRC=AIM-CIS/invoiceheader',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "invoiceheader","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'invoiceheader',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "invoiceheader","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/invoiceheader'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/invoiceheader')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'invoiceheader' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject invoiceheader not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_invoiceheader_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_invoiceheader_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: invoicetrancode  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/invoicetrancode')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'invoicetrancode',
	 'Merge/Protected/SRC=AIM-CIS/invoicetrancode',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "invoicetrancode","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'invoicetrancode',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "invoicetrancode","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/invoicetrancode'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/invoicetrancode')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'invoicetrancode' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject invoicetrancode not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_invoicetrancode_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_invoicetrancode_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: policy  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/policy')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'policy',
	 'Merge/Protected/SRC=AIM-CIS/policy',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "policy","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'policy',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "policy","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/policy'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/policy')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'policy' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject policy not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_policy_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_policy_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: producer  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/producer')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'producer',
	 'Merge/Protected/SRC=AIM-CIS/producer',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "producer","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'producer',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "producer","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/producer'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/producer')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'producer' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject producer not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_producer_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_producer_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: product  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/product')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'product',
	 'Merge/Protected/SRC=AIM-CIS/product',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "product","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'product',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "product","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/product'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/product')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'product' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject product not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_product_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_product_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: quote  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/quote')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'quote',
	 'Merge/Protected/SRC=AIM-CIS/quote',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "quote","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'quote',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "quote","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/quote'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/quote')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'quote' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject quote not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_quote_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_quote_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: taaproductionsplit  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/taaproductionsplit')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'taaproductionsplit',
	 'Merge/Protected/SRC=AIM-CIS/taaproductionsplit',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "taaproductionsplit","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'taaproductionsplit',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "taaproductionsplit","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/taaproductionsplit'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/taaproductionsplit')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'taaproductionsplit' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject taaproductionsplit not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_taaproductionsplit_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_taaproductionsplit_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: team  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/team')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'team',
	 'Merge/Protected/SRC=AIM-CIS/team',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "team","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'team',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "team","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/team'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/team')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'team' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject team not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_team_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_team_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: userid  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/userid')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'userid',
	 'Merge/Protected/SRC=AIM-CIS/userid',
	 '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "userid","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'userid',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_CIS","externalTableName": "userid","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/userid'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-CIS/userid')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'userid' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject userid not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_userid_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_userid_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID
