
-- =============================================
-- Source Name: AIM-AFD
-- Date Created: 2024-04-01
-- Description: MDMF dbo.DMergeConfig Insert Script
-- =============================================


DECLARE 
    @factoryId BIGINT = (SELECT FwkFactoryId FROM dbo.FwkFactory WHERE FactoryName = '{#factoryName#}'),
    @triggerIdHist BIGINT = (SELECT FwkTriggerId FROM dbo.FwkTrigger WHERE TriggerName = 'TR_EDH_History'),
    @triggerIdCDC BIGINT = (SELECT FwkTriggerId FROM dbo.FwkTrigger WHERE TriggerName = 'TR_EDH_15Min'),
    @targetId BIGINT = (SELECT FwkTargetId FROM dbo.FwkTarget WHERE TargetName = 'adls-bronze-protected'),
    @sourceId BIGINT = (SELECT FwkSourceId FROM dbo.FwkSource WHERE SourceName = 'AIM-AFD'),
    @fwkConfigId BIGINT,
    @dSplitConfigId BIGINT,
    @dSplitEntityUID nvarchar(50),
	@dmOutputId BIGINT,
    @error nvarchar(255)

IF @factoryId IS NULL
    throw 500401, 'FactoryName {#factoryName#} not found in dbo.FwkFactory', 1

IF @triggerIdHist IS NULL
    throw 500401, 'TriggerName TR_EDH_History not found in dbo.FwkTrigger', 1

IF @triggerIdCDC IS NULL
    throw 500401, 'TriggerName TR_EDH_15Min not found in dbo.FwkTrigger', 1

IF @sourceId IS NULL
    throw 500401, 'SourceName AIM-AFD not found in dbo.FwkSource', 1

IF @targetId IS NULL
    throw 500401, 'TargetName adls-bronze-protected not found in dbo.FwkTarget', 1

/****** Object: cstctr  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @TargetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/cstctr')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @TargetId,
	 'cstctr',
	 'Merge/Protected/SRC=AIM-AFD/cstctr',
	 '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "cstctr","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'cstctr',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "cstctr","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId =@TargetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/cstctr'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId =@TargetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/cstctr')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'cstctr' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject cstctr not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_cstctr_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_cstctr_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: tacacctmaster  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @TargetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/tacacctmaster')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @TargetId,
	 'tacacctmaster',
	 'Merge/Protected/SRC=AIM-AFD/tacacctmaster',
	 '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "tacacctmaster","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'tacacctmaster',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "tacacctmaster","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId =@TargetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/tacacctmaster'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId =@TargetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/tacacctmaster')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'tacacctmaster' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject tacacctmaster not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_tacacctmaster_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_tacacctmaster_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: tacglhistory  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @TargetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/tacglhistory')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @TargetId,
	 'tacglhistory',
	 'Merge/Protected/SRC=AIM-AFD/tacglhistory',
	 '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "tacglhistory","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'tacglhistory',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "tacglhistory","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId =@TargetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/tacglhistory'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId =@TargetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/tacglhistory')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'tacglhistory' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject tacglhistory not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_tacglhistory_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_tacglhistory_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: cstctr  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @TargetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/cstctr')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @TargetId,
	 'cstctr',
	 'Merge/Protected/SRC=AIM-AFD/cstctr',
	 '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "cstctr","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'cstctr',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "cstctr","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId =@TargetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/cstctr'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId =@TargetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/cstctr')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'cstctr' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject cstctr not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_cstctr_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_cstctr_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: tacacctmaster  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @TargetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/tacacctmaster')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @TargetId,
	 'tacacctmaster',
	 'Merge/Protected/SRC=AIM-AFD/tacacctmaster',
	 '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "tacacctmaster","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'tacacctmaster',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "tacacctmaster","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId =@TargetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/tacacctmaster'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId =@TargetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/tacacctmaster')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'tacacctmaster' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject tacacctmaster not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_tacacctmaster_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_tacacctmaster_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: tacglhistory  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @TargetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/tacglhistory')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @TargetId,
	 'tacglhistory',
	 'Merge/Protected/SRC=AIM-AFD/tacglhistory',
	 '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "tacglhistory","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'tacglhistory',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "tacglhistory","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId =@TargetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/tacglhistory'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId =@TargetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/tacglhistory')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'tacglhistory' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject tacglhistory not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_tacglhistory_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_tacglhistory_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID
