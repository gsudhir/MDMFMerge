
-- =============================================
-- Source Name: AIM-AFD
-- Date Created: 2024-03-19
-- Description: MDMF dbo.DMergeConfig Insert Script
-- =============================================


DECLARE 
    @factoryId BIGINT = (SELECT FwkFactoryId FROM dbo.FwkFactory WHERE FactoryName = '{#factoryName#}'),
    @triggerIdHist BIGINT = (SELECT FwkTriggerId FROM dbo.FwkTrigger WHERE TriggerName = 'TR_EDH_History'),
    @triggerIdCDC BIGINT = (SELECT FwkTriggerId FROM dbo.FwkTrigger WHERE TriggerName = 'TR_EDH_15Min'),
    @targetId BIGINT = (SELECT FwkTargetId FROM dbo.FwkTarget WHERE TargetName = 'adls-bronze-protected'),
    @sourceId BIGINT = (SELECT FwkSourceId FROM dbo.FwkSource WHERE SourceName = 'AIM-AFD'),
    @fwkConfigId BIGINT,
    @dSplitConfigId BIGINT,
    @dSplitEntityUID nvarchar(50),
	@dmOutputId BIGINT,
    @error nvarchar(255)

IF @factoryId IS NULL
    throw 500401, 'FactoryName {#factoryName#} not found in dbo.FwkFactory', 1

IF @triggerIdHist IS NULL
    throw 500401, 'TriggerName TR_EDH_History not found in dbo.FwkTrigger', 1

IF @triggerIdCDC IS NULL
    throw 500401, 'TriggerName TR_EDH_15Min not found in dbo.FwkTrigger', 1

IF @sourceId IS NULL
    throw 500401, 'SourceName AIM-AFD not found in dbo.FwkSource', 1

IF @targetId IS NULL
    throw 500401, 'TargetName adls-bronze-protected not found in dbo.FwkTarget', 1

/****** Object: acct  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/acct')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'acct',
	 'Merge/Protected/SRC=AIM-AFD/acct',
	 '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "acct","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'acct',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "acct","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/acct'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/acct')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'acct' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject acct not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_acct_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_acct_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: ap  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/ap')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'ap',
	 'Merge/Protected/SRC=AIM-AFD/ap',
	 '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "ap","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'ap',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "ap","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/ap'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/ap')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'ap' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject ap not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_ap_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_ap_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: ar  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/ar')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'ar',
	 'Merge/Protected/SRC=AIM-AFD/ar',
	 '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "ar","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'ar',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "ar","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/ar'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/ar')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'ar' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject ar not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_ar_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_ar_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: batchttl  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/batchttl')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'batchttl',
	 'Merge/Protected/SRC=AIM-AFD/batchttl',
	 '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "batchttl","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'batchttl',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "batchttl","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/batchttl'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/batchttl')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'batchttl' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject batchttl not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_batchttl_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_batchttl_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

/****** Object: gl  ******/

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmOutput
	WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/gl')
INSERT INTO dbo.DmOutput (
	FwkFactoryId,
	FwkTargetId,
	ObjectName,
	OutputFilePath,
	InputParameters,
	DmEntityUID,
	BatchGroupId,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @factoryId,
	 @targetId,
	 'gl',
	 'Merge/Protected/SRC=AIM-AFD/gl',
	 '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "gl","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	 NEWID(),
	 NULL,
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmOutput
SET
	FwkFactoryId = @factoryId,
	ObjectName = 'gl',
	InputParameters = '{"externalDatabaseName": "bronze_AIM_AFD","externalTableName": "gl","numPartitions": null,"shufflePartitions": null,"createExternalTableConformed": "N","createExternalTable": "Y","deltaPartitionColumns": [],"deltaOutputColumns": [],"deltaVacuumDays": 1}',
	BatchGroupId = NULL,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	FwkTargetId = @targetId AND
	OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/gl'

SET @dmOutputId = (SELECT DmOutputId FROM dbo.DmOutput WHERE 
		FwkTargetId = @targetId AND
		OutputFilePath = 'Merge/Protected/SRC=AIM-AFD/gl')

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'gl' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject gl not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdHist,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdHist,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID

SET @fwkConfigId = (
	SELECT FwkConfigId
	FROM dbo.FwkConfig
	WHERE 
		SrcObject = 'dbo_gl_CT' AND
		FwkSourceId = @sourceId)

IF @fwkConfigId IS NULL
	throw 500401, 'SrcObject dbo_gl_CT not found in dbo.FwkConfig', 1

SET @dSplitConfigId = (
	SELECT DSplitConfigId
	FROM dbo.DSplitConfig
	WHERE FwkConfigId = @fwkConfigId)

IF @dSplitConfigId IS NULL
BEGIN
	SET @error = concat('FwkConfigId ', cast(@fwkConfigId as nvarchar), ' not found in dbo.DSplitConfig');
	THROW 500401, @error, 1
END

SET @dSplitEntityUID = (SELECT DSplitEntityUID FROM dbo.DSplitOutput WHERE DSplitConfigId = @dSplitConfigId)

IF @dSplitEntityUID IS NULL
BEGIN
	SET @error = concat('DSplitConfigId ', cast(@dSplitConfigId as nvarchar), ' not found in dbo.DSplitOutput');
	THROW 500401, @error, 1
END

IF NOT EXISTS (
	SELECT 1
	FROM dbo.DmMapping
	WHERE 
		SourceEntityUID = @dSplitEntityUID)
INSERT INTO dbo.DmMapping (
	FwkTriggerId,
	DmOutputId,
	SourceEntityUID,
	SourceEntityModule,
	ActiveFlag,
	LastModifiedDate,
	LastModifiedBy)
 VALUES (
	 @triggerIdCDC,
	 @dmOutputId,
	 @dSplitEntityUID,
	 'Data Split',
	 'Y',
	 GETDATE(),
	 CURRENT_USER)
ELSE
UPDATE dbo.DmMapping
SET
	FwkTriggerId = @triggerIdCDC,
	DmOutputId = @dmOutputId,
	SourceEntityUID = @dSplitEntityUID,
	ActiveFlag = 'Y',
	LastModifiedDate = GETDATE(),
	LastModifiedBy = CURRENT_USER
WHERE
	SourceEntityUID = @dSplitEntityUID
