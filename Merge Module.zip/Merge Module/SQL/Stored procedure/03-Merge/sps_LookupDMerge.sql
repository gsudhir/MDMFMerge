
-- =============================================
-- Create Date: 2023-11-01
-- Description: MDMF dbo.sps_LookupDMerge object creation script. Gets all the necesary information to orchestrate the Data Merge process.
-- =============================================


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

DROP PROCEDURE IF EXISTS [dbo].[sps_LookupDMerge]   
GO

CREATE PROCEDURE [dbo].[sps_LookupDMerge]
(
    @FactoryName nvarchar(50),
	@MainRunId nvarchar(50),
	@ModuleRunId nvarchar(50),
	@TriggerName nvarchar(100),
	@DMergeLogIds nvarchar(4000) = NULL,
	@BatchGroupId bigint = NULL
)
AS
BEGIN

    SET NOCOUNT ON

    SELECT 
		L.DMergeLogId,
		L.FwkLogId,
		L.FwkFactoryId,
		L.FactoryName,
		L.FactoryParameters,
		L.MainRunId,
		L.ModuleRunId,
		L.PipelineStartTime,
		L.FwkTriggerId,
		L.TriggerName,
		L.FwkConfigId,
		L.ObjectName,
		L.SourceModuleName,
		L.SourceInstanceURL,
		L.SourceContainerName,
		L.SourceFilePath,
		L.SourceKeySecretName,
		L.SourceFileExtension,
		L.FwkObjectMetadataId,
		L.ObjectSchema,
		L.ColumnSchema,
		L.DMergeConfigId,
		L.InputParameters,
		L.OutputParameters,
		L.BatchGroupId,
		L.ActiveFlag,
		GP_NB.GlobalParamValue AS NotebookPath,
		W.NewValueWmkDt AS CurrentValueWmkDt,
		W.NewValueWmkCustom AS CurrentValueWmkCustom
	FROM DMergeLog L WITH (NOLOCK)
	LEFT JOIN FwkGlobalParam GP_NB WITH (NOLOCK)
		ON GP_NB.FwkFactoryId = L.FwkFactoryId AND GP_NB.GlobalParamName = 'NbPathDataMerge'
	LEFT JOIN FwkWatermark W WITH (NOLOCK)
		ON W.FwkConfigId = L.FwkConfigId AND W.ObjectName = L.ObjectName
	WHERE L.FactoryName = @FactoryName
		AND L.MainRunId = @MainRunId
		AND (L.DMergeLogId IN (SELECT [value] FROM string_split(@DMergeLogIds,',')) OR @DMergeLogIds IS NULL)
		AND (L.PipelineStatus = 'Failed' OR L.PipelineStatus IS NULL) --failed or not started
		AND (L.ActivityStatus = 'Failed' OR L.ActivityStatus IS NULL) --failed or not started
		AND (L.NbStatus = 'Failed' OR L.NbStatus IS NULL) --failed or not started
		AND L.ActiveFlag = 'Y'
		AND (ISNULL(L.BatchGroupId, -1) = @BatchGroupId OR @BatchGroupId IS NULL)
END
GO