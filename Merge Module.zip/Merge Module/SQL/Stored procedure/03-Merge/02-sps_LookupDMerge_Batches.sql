
-- =============================================
-- Create Date: 2023-11-01
-- Description: MDMF dbo.sps_LookupDMerge_Batches object creation script. Get distinct BatchGroupId values 
--			    for the specific MainRunId, this is to do a sequential Data Merge process.
-- =============================================


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

DROP PROCEDURE IF EXISTS [dbo].[sps_LookupDMerge_Batches]   
GO

CREATE PROCEDURE [dbo].[sps_LookupDMerge_Batches]
(
    @FactoryName nvarchar(50),
	@MainRunId nvarchar(50),
	@ModuleRunId nvarchar(50),
	@TriggerName nvarchar(100),
	@ModuleName nvarchar(50),
	@PipelineName nvarchar(50),
	@PipelineTriggerId nvarchar(50),
	@PipelineTriggerType nvarchar(50),
	@DMergeLogIds nvarchar(4000) = NULL
)
AS
BEGIN

	SET NOCOUNT ON;

	--overwritting parameters @ModuleRunId, @TriggerName based on MainRunId, this is when re-executing the module using MainRunId
	SELECT TOP 1 @ModuleRunId = ModuleRunId, @TriggerName = PipelineTriggerName FROM FwkLog WITH (NOLOCK) WHERE FactoryName = @FactoryName AND MainRunId = @MainRunId AND ModuleName = @ModuleName;

	--creating FwkLog record
	EXEC [spi_FwkLogInsert] @FactoryName = @FactoryName, @MainRunId = @MainRunId, @ModuleRunId = @ModuleRunId, @ModuleName = @ModuleName, @PipelineName = @PipelineName, @PipelineTriggerId = @PipelineTriggerId, @PipelineTriggerName = @TriggerName, @PipelineTriggerType = @PipelineTriggerType;

	--deleting failed or not started log records of the current MainRunId, this is in order to pick up recent configuration changes for a re-execution
	IF @DMergeLogIds IS NULL
	BEGIN
		DELETE FROM DMergeLog WHERE FactoryName = @FactoryName AND MainRunId = @MainRunId AND (ActivityStatus = 'Failed' OR ActivityStatus IS NULL);
	END

	--creating log records to orchestrate the pipeline execution
	EXEC [spi_DMergeLogInsert] @FactoryName = @FactoryName, @MainRunId = @MainRunId, @ModuleRunId = @ModuleRunId, @TriggerName = @TriggerName;

	--return the list of batches to process
    SELECT DISTINCT
		ISNULL(L.BatchGroupId, -1) AS BatchGroupId 
	FROM DMergeLog L WITH (NOLOCK)
	WHERE L.FactoryName = @FactoryName
		AND L.MainRunId = @MainRunId
		AND (L.DMergeLogId IN (SELECT [value] FROM string_split(@DMergeLogIds,',')) OR @DMergeLogIds IS NULL)
		AND (L.PipelineStatus = 'Failed' OR L.PipelineStatus IS NULL) --failed or not started
		AND (L.ActivityStatus = 'Failed' OR L.ActivityStatus IS NULL) --failed or not started
		AND (L.NbStatus = 'Failed' OR L.NbStatus IS NULL) --failed or not started
		AND L.ActiveFlag = 'Y'
	ORDER BY ISNULL(L.BatchGroupId, -1) ASC --NULL group goes first
END
GO