
-- =============================================
-- Create Date: 2023-11-01
-- Description: MDMF dbo.spu_DMergeLogUpdate object creation script. Updates the DMergeLog details of the data merge module.
-- =============================================


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

DROP PROCEDURE IF EXISTS [dbo].[spu_DMergeLogUpdate]   
GO

CREATE PROCEDURE [dbo].[spu_DMergeLogUpdate]
(
    @DMergeLogId bigint,
	@Type nvarchar(50),
	@PipelineRunId nvarchar(50) = NULL,
	@PipelineName nvarchar(50) = NULL,
	@PipelineStatus nvarchar(50) = NULL,
	@PipelineError nvarchar(max) = NULL,
	@ActivityRunId nvarchar(50) = NULL,
	@ActivityName nvarchar(50) = NULL,
	@ActivityType nvarchar(50) = NULL,
	@ActivityStartTime datetime2 = NULL,
	@ActivityEndTime datetime2 = NULL,
	@ActivityDuration nvarchar(50) = NULL,
	@ActivityStatus nvarchar(50) = NULL,
	@ActivityError nvarchar(max) = NULL,
	@ActivityIntegrationRuntime nvarchar(max) = NULL,
	@ActivityOutputDetail nvarchar(max) = NULL,
	@NbStatus nvarchar(50) = NULL,
	@NbRunPageURL nvarchar(500) = NULL,
	@NbRunError nvarchar(max) = NULL,
	@NbRunOutput nvarchar(MAX) = NULL
)
AS
BEGIN

    SET NOCOUNT ON

    DECLARE 
		@LastModifiedDate datetime2 = GETDATE(),
		@LastModifiedBy nvarchar(100) = SUSER_SNAME();

	IF @Type = 'PipelineDetailStart'
		BEGIN
			UPDATE [dbo].[DMergeLog] 
			SET
				[PipelineRunId] = @PipelineRunId,
				[PipelineName] = @PipelineName,
				[PipelineStartTime] = GETDATE(),
				[PipelineEndTime] = NULL,
				[PipelineDuration] = NULL,
				[PipelineStatus] = NULL,
				[PipelineError] = NULL,
				[ActivityRunId] = NULL,
				[ActivityName] = NULL,
				[ActivityType] = NULL,
				[ActivityStartTime] = NULL,
				[ActivityEndTime] = NULL,
				[ActivityDuration] = NULL,
				[ActivityStatus] = NULL,
				[ActivityError] = NULL,
				[ActivityIntegrationRuntime] = NULL,
				[ActivityOutputDetail] = NULL,
				[NbStatus] = NULL,
				[NbRunPageURL] = NULL,
				[NbRunError] = NULL,
				[NbRunOutput] = NULL
			WHERE 
				DMergeLogId = @DMergeLogId
		END
	ELSE IF @Type = 'PipelineDetailEnd'
		BEGIN
			UPDATE [dbo].[DMergeLog] 
			SET
				[PipelineRunId] = @PipelineRunId,
				[PipelineName] = @PipelineName,
				[PipelineEndTime] = GETDATE(),
				[PipelineDuration] = DATEDIFF(SS, [PipelineStartTime], GETDATE()),
				[PipelineStatus] = @PipelineStatus,
				[PipelineError] = @PipelineError,
				[ActivityRunId] = @ActivityRunId,
				[ActivityName] = @ActivityName,
				[ActivityType] = @ActivityType,
				[ActivityStartTime] = @ActivityStartTime,
				[ActivityEndTime] = @ActivityEndTime,
				[ActivityDuration] = @ActivityDuration,
				[ActivityStatus] = @ActivityStatus,
				[ActivityError] = @ActivityError,
				[ActivityIntegrationRuntime] = @ActivityIntegrationRuntime,
				[ActivityOutputDetail] = @ActivityOutputDetail,
				[NbStatus] = @NbStatus,
				[NbRunPageURL] = @NbRunPageURL,
				[NbRunError] = @NbRunError,
				[NbRunOutput] = @NbRunOutput,
				[LastModifiedDate] = @LastModifiedDate,
				[LastModifiedBy] = @LastModifiedBy
			WHERE 
				DMergeLogId = @DMergeLogId;


			/*** The following code is only when ingestionSkipped functionality is active, we need to update the FwkWatermark table after Merge module succeeded ***/
			DECLARE 
				@FwkConfigId bigint,
				@ObjectName nvarchar(255),
				@PipelineStartTime datetime2;
			
			SELECT 
				@FwkConfigId = L.FwkConfigId,
				@ObjectName = L.ObjectName,
				@PipelineStartTime = L.PipelineStartTime
			FROM DMergeLog L WITH (NOLOCK) 
			WHERE L.DMergeLogId = @DMergeLogId 
				AND JSON_VALUE(L.ObjectSchema,'$."skipIngestion"') = 'Y'; --only when ingestionSkipped functionality is active

			IF @FwkConfigId IS NOT NULL --only when ingestionSkipped functionality is active
			BEGIN
				DECLARE 
					@FwkWatermarkId bigint = (SELECT FwkWatermarkId FROM FwkWatermark W WITH (NOLOCK) WHERE W.FwkConfigId = @FwkConfigId AND W.ObjectName = @ObjectName),
					@NewValueWmkDt nvarchar(50) = FORMAT(@PipelineStartTime,'yyyy-MM-dd HH:mm:ss.fff');

				EXEC [spu_FwkWatermarkDtUpdate] @FwkWatermarkId, @FwkConfigId, @ObjectName, @NewValueWmkDt;
			END
			/********************************************************************************************************************************/

		END
END
GO