
-- =============================================
-- Create Date: 2023-11-01
-- Description: MDMF dbo.spi_DMergeLogInsert object creation script. Insert logs on DMergeLog table, this is to orchestrate the data merge module.
-- =============================================


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

DROP PROCEDURE IF EXISTS [dbo].[spi_DMergeLogInsert]   
GO

CREATE PROCEDURE [dbo].[spi_DMergeLogInsert]
(
	@FactoryName nvarchar(50),
	@MainRunId nvarchar(50),
	@ModuleRunId nvarchar(50),
	@TriggerName nvarchar(100)
)
AS  
BEGIN  

	SET NOCOUNT ON;

	DECLARE 
		@LastModifiedDate datetime2 = GETDATE(),
		@LastModifiedBy nvarchar(100) = SUSER_SNAME();

	--temporary tables with the DataSplitLog items that were processed on current MainRunId, this temporary tables helps to avoid querying twice when inserting on DMergeLog
	IF OBJECT_ID('tempdb..#tmpDSplitLog') IS NOT NULL
		DROP TABLE #tmpDSplitLog;
	SELECT L.*, 
		F.FwkFactoryId AS DMergeFwkFactoryId, 
		F.FactoryName AS DMergeFactoryName,
		F.FactoryParameters AS DMergeFactoryParameters,
		Tgt.FwkTargetId AS DMergeFwkTargetId,
		T.FwkTriggerId AS DMergeFwkTriggerId,
		T.TriggerName AS DMergeTriggerName,
		JSON_VALUE(J2.[value],'$.outputInstanceURL') AS DMergeSourceInstanceURL,
		JSON_VALUE(J2.[value],'$.outputContainerName') AS DMergeSourceContainerName,
		JSON_VALUE(J2.[value],'$.outputFilePath') AS DMergeSourceFilePath,
		JSON_VALUE(J2.[value],'$.outputFileExtension') AS DMergeSourceFileExtension,
		JSON_VALUE(J2.[value],'$.outputKeySecretName') AS DMergeSourceKeySecretName,
		Tgt.InstanceURL AS DMergeOutputInstanceURL,
		Tgt.ContainerName AS DMergeOutputContainerName,
		ISNULL(Tgt.KeySecretName,'') AS DMergeOutputKeySecretName,
		UPPER(ISNULL(JSON_VALUE(L.ObjectSchema,'$.extractionType'),'FULL')) AS DMergeOutputExtractionType
	INTO #tmpDSplitLog
	FROM DSplitLog L WITH (NOLOCK)
	CROSS APPLY OPENJSON(L.OutputParameters) J --main level
	CROSS APPLY OPENJSON(J.[value],'$.outputs') J2 --outputs level
	INNER JOIN FwkLog FL_Split WITH (NOLOCK)
		ON FL_Split.FwkLogId = L.FwkLogId
	INNER JOIN FwkTarget Tgt WITH (NOLOCK)
		ON Tgt.FwkTargetId = JSON_VALUE(J2.[value], '$.fwkTargetId')
	INNER JOIN FwkFactory F WITH (NOLOCK)
		ON F.FwkFactoryId = Tgt.FwkFactoryId
	INNER JOIN FwkTrigger T WITH (NOLOCK)
		ON T.FwkTriggerId = L.FwkTriggerId
	WHERE 
		F.FactoryName = @FactoryName
		AND FL_Split.MainRunId = @MainRunId --retriving data split items from MainRunId
		AND T.TriggerName = @TriggerName
		AND L.PipelineStatus = 'Succeeded'
		AND L.ActivityStatus = 'Succeeded'
		AND L.NbStatus = 'Succeeded'
		AND L.ActiveFlag = 'Y'
		AND Tgt.ActiveFlag = 'Y'
		AND F.ActiveFlag = 'Y'
		AND T.ActiveFlag = 'Y'
	;

	--Insert DMergeLog from Data Split module
	INSERT INTO [dbo].[DMergeLog] (
		[DSplitLogId],
		[FwkLogId],
		[FwkFactoryId],
		[FactoryName],
		[FactoryParameters],
		[MainRunId],
		[ModuleRunId],
		[ModuleName],
		[PipelineStartTime],
		[FwkConfigId],
		[ObjectName],
		[SourceModuleName],
		[SourceInstanceURL],
		[SourceContainerName],
		[SourceFilePath],
		[SourceFileExtension],
		[SourceKeySecretName],
		[SourceName],
		[FwkObjectMetadataId],
		[ObjectSchema],
		[ColumnSchema],
		[FwkTriggerId],
		[TriggerName],
		[DMergeConfigId],
		[FwkTargetId],
		[DSplitConfigId],
		[InputParameters],
		[OutputParameters],
		[DMergeEntityUID],
		[BatchGroupId],
		[ActiveFlag],
		[LastModifiedDate],
		[LastModifiedBy]
	)
	SELECT 
		L.DSplitLogId,
		FL.FwkLogId,
		L.DMergeFwkFactoryId,
		L.DMergeFactoryName,
		L.DMergeFactoryParameters,
		@MainRunId,
		FL.ModuleRunId,
		'Data Merge',
		GETDATE() AS PipelineStartTime,
		L.FwkConfigId,
		L.ObjectName,
		'Data Split' AS SourceModule,
		L.DMergeSourceInstanceURL,
		L.DMergeSourceContainerName,
		CONCAT(L.DMergeSourceFilePath,'/*.',L.DMergeSourceFileExtension) AS DsSourceFilePath,
		L.DMergeSourceFileExtension,
		L.DMergeSourceKeySecretName,
		IsNull(S.SourceName,'{}') AS SourceName,
		L.FwkObjectMetadataId,
		L.ObjectSchema,
		L.ColumnSchema,
		L.DMergeFwkTriggerId,
		L.DMergeTriggerName,
		DmC.DMergeConfigId,
		DmC.FwkTargetId,
		L.DSplitConfigId,
		DmC.InputParameters AS InputParameters,
		CONCAT(
			'{"sourceName":"', IsNull(S.SourceName, ''), '","outputInstanceURL":"',L.DMergeOutputInstanceURL,
			'","outputContainerName":"', L.DMergeOutputContainerName, '","outputFilePath":"', CONCAT('Merge/Protected/SRC=',
			S.SourceName,'/', CASE WHEN C.SrcDbSchema = 'cdc' THEN (SELECT SrcDbSchema FROM FwkConfig WHERE SrcObject = DmC.ObjectName
			AND FwkSourceId = C.FwkSourceId) ELSE C.SrcDbSchema END ,'_', DmC.ObjectName), '","outputFileExtension":"delta",
			"outputKeySecretName":"', L.DMergeOutputKeySecretName,'","loadDate":"', CAST(GETDATE() as datetime2), '","deltaContainerName":"bronze"}'
		) AS OutputParameters,
		DmC.DMergeEntityUID,
		DmC.BatchGroupId,
		'Y',
		@LastModifiedDate,
		@LastModifiedBy
	FROM #tmpDSplitLog L
	INNER JOIN DMergeConfig DmC WITH (NOLOCK)
		ON DmC.FwkConfigId = L.FwkConfigId AND DmC.FwkTargetId = L.DMergeFwkTargetId
	INNER JOIN FwkConfig C WITH (NOLOCK)
        ON C.FwkConfigId = L.FwkConfigId
	INNER JOIN FwkSource S WITH (NOLOCK)
        ON S.FwkSourceId = C.FwkSourceId
	INNER JOIN FwkLog FL WITH (NOLOCK)
		ON FL.FwkFactoryId = L.FwkFactoryId AND FL.MainRunId = @MainRunId AND FL.ModuleName = 'Data Merge'
	WHERE 
		--excluding records that already exists on the MainRunId, this is when re-executing the failed MainRunId
		NOT EXISTS (SELECT 1 FROM DMergeLog L2 WITH (NOLOCK) WHERE L2.FwkFactoryId = DmC.FwkFactoryId AND L2.FwkConfigId = DmC.FwkConfigId AND DmC.ObjectName = L2.ObjectName AND DmC.FwkTargetId = L2.FwkTargetId AND L2.MainRunId = @MainRunId) 
		--control fields
		AND DmC.ActiveFlag = 'Y'
	;

END
GO